"use client";
import { useState } from "react";
import { z } from "zod";
import type {
  DirectoryInputs,
  DirectoryKind,
} from "@/lib/api-client/university-management";
import { getApiFieldErrors, normalizeApiError } from "@/lib/api-client/error";
import { useDirectoryList } from "@/hook/queries/use-university-management";
import { useDirectoryCreate } from "@/hook/mutations/use-university-management";
import { useContentSelectors } from "@/hook/queries/use-content-queries";
import { useAdminAccess } from "@/providers/admin-access-provider";
import { cityInputSchema, majorInputSchema } from "@/lib/university-schemas";
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/dashboard/states";
import { buttonClass, inputClass, PageControls, panelClass } from "./controls";

export function DirectoryPage<K extends DirectoryKind>({ kind }: { kind: K }) {
  const [params, setParams] = useState({
    page: 1,
    limit: 12,
    search: "",
    countryId: "",
  });
  const [adding, setAdding] = useState(false);
  const [values, setValues] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState("");
  const access = useAdminAccess();
  const countries = useContentSelectors({ countries: kind === "cities" });
  const list = useDirectoryList(kind, {
    ...params,
    search: params.search.trim() || undefined,
    countryId: params.countryId || undefined,
  });
  const create = useDirectoryCreate(kind);
  const title = kind === "cities" ? "المدن" : "التخصصات الأكاديمية";
  if (access.mockEnabled)
    return (
      <p>
        كتالوج {title} يتطلب جلسة Backend؛ لا تُرسل بيانات المعاينة إلى الخادم.
      </p>
    );
  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <h2 className="flex-1 text-2xl font-bold">{title}</h2>
        <button
          className={buttonClass}
          onClick={() => {
            setAdding(true);
            setMessage("");
          }}
        >
          إضافة سجل
        </button>
      </div>
      <p className="text-sm">
        العقد يدعم الاستعراض والإضافة فقط؛ لا توجد إجراءات تعديل أو حذف غير
        موثقة.
      </p>
      <form
        className={`${panelClass} flex flex-wrap gap-3`}
        onSubmit={(event) => {
          event.preventDefault();
          const data = new FormData(event.currentTarget);
          setParams({
            page: 1,
            limit: Number(data.get("limit")),
            search: String(data.get("search") ?? ""),
            countryId: String(data.get("countryId") ?? ""),
          });
        }}
      >
        <input
          aria-label="بحث الكتالوج"
          name="search"
          maxLength={200}
          className={`${inputClass} sm:!w-auto`}
          placeholder="بحث"
        />
        {kind === "cities" ? (
          <select
            aria-label="تصفية الدولة"
            name="countryId"
            className={`${inputClass} sm:!w-auto`}
          >
            <option value="">كل الدول</option>
            {countries.countries.data?.items.map((item) => (
              <option key={item.id} value={item.id}>
                {item.nameAr}
              </option>
            ))}
          </select>
        ) : null}
        <select
          aria-label="عدد السجلات"
          name="limit"
          defaultValue="12"
          className={`${inputClass} sm:!w-auto`}
        >
          {[12, 24, 50].map((value) => (
            <option key={value}>{value}</option>
          ))}
        </select>
        <button className={buttonClass}>تطبيق المرشحات</button>
      </form>
      {adding ? (
        <form
          className={panelClass}
          noValidate
          onSubmit={async (event) => {
            event.preventDefault();
            setErrors({});
            setMessage("");
            try {
              const input = (
                kind === "cities" ? cityInputSchema : majorInputSchema
              ).parse({
                ...values,
                ...(kind === "academic-majors"
                  ? { category: values.category?.trim() || null }
                  : {}),
              }) as DirectoryInputs[K];
              await create.mutateAsync(input);
              setAdding(false);
              setValues({});
              setMessage("تمت إضافة السجل.");
            } catch (error) {
              if (error instanceof z.ZodError)
                setErrors(
                  Object.fromEntries(
                    error.issues.map((issue) => [
                      String(issue.path[0]),
                      "تحقق من القيمة المطلوبة وصيغتها.",
                    ]),
                  ),
                );
              else {
                setErrors(
                  Object.fromEntries(
                    Object.entries(getApiFieldErrors(error)).map(
                      ([key, messages]) => [key, messages[0]],
                    ),
                  ),
                );
                setMessage(
                  normalizeApiError(error).status === 409
                    ? "المعرّف النصي مستخدم بالفعل. لم تُفقد البيانات."
                    : "تعذّر الحفظ. راجع القيم والاتصال.",
                );
              }
            }
          }}
        >
          <fieldset
            disabled={create.isPending}
            className="grid min-w-0 gap-4 sm:grid-cols-2"
          >
            {[
              "nameAr",
              "nameEn",
              "slug",
              ...(kind === "academic-majors" ? ["category"] : []),
            ].map((name) => (
              <label key={name} className="grid gap-1 text-sm font-semibold">
                {
                  (
                    {
                      nameAr: "الاسم بالعربية *",
                      nameEn: "الاسم بالإنجليزية *",
                      slug: "المعرّف النصي *",
                      category: "التصنيف (اختياري)",
                    } as Record<string, string>
                  )[name]
                }
                <input
                  aria-label={name}
                  dir={name === "nameAr" ? "rtl" : "ltr"}
                  className={inputClass}
                  maxLength={name === "slug" || name === "category" ? 120 : 200}
                  value={values[name] ?? ""}
                  onChange={(event) =>
                    setValues((old) => ({ ...old, [name]: event.target.value }))
                  }
                />
                {errors[name] ? (
                  <span role="alert" className="text-red-700">
                    {errors[name]}
                  </span>
                ) : null}
              </label>
            ))}
            {kind === "cities" ? (
              <label className="grid gap-1 text-sm">
                الدولة *
                <select
                  aria-label="دولة المدينة"
                  className={inputClass}
                  value={values.countryId ?? ""}
                  onChange={(event) =>
                    setValues((old) => ({
                      ...old,
                      countryId: event.target.value,
                    }))
                  }
                >
                  <option value="">اختر الدولة</option>
                  {countries.countries.data?.items.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.nameAr}
                    </option>
                  ))}
                </select>
                {errors.countryId ? (
                  <span role="alert">{errors.countryId}</span>
                ) : null}
              </label>
            ) : null}
          </fieldset>
          <div className="flex gap-3">
            <button className={buttonClass} disabled={create.isPending}>
              حفظ السجل
            </button>
            <button
              type="button"
              className={buttonClass}
              disabled={create.isPending}
              onClick={() => setAdding(false)}
            >
              إلغاء
            </button>
          </div>
        </form>
      ) : null}
      {countries.countries.isError ? (
        <p role="alert">
          تعذّر تحميل الدول.{" "}
          <button onClick={() => void countries.countries.refetch()}>
            إعادة المحاولة
          </button>
        </p>
      ) : null}
      {message ? <p role="status">{message}</p> : null}
      {list.isPending ? (
        <LoadingState />
      ) : list.isError ? (
        <ErrorState
          action={
            <button className={buttonClass} onClick={() => void list.refetch()}>
              إعادة المحاولة
            </button>
          }
        />
      ) : list.data.items.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {list.data.items.map((item) => (
            <article key={item.id} className={panelClass}>
              <h3 className="break-words font-bold">{item.nameAr}</h3>
              <p dir="ltr" className="break-words text-sm">
                {item.nameEn} · {item.slug}
              </p>
              {"category" in item ? (
                <p className="text-sm">{item.category ?? "دون تصنيف"}</p>
              ) : "countryId" in item ? (
                <p className="text-sm">
                  {item.country?.nameAr ??
                    countries.countries.data?.items.find(
                      (country) => country.id === item.countryId,
                    )?.nameAr ??
                    "—"}
                </p>
              ) : null}
            </article>
          ))}
        </div>
      )}
      <PageControls
        data={list.data}
        change={(page) => setParams((old) => ({ ...old, page }))}
      />
    </section>
  );
}
