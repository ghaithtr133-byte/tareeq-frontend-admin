"use client";
/* eslint-disable @next/next/no-img-element */
import { useState } from "react";
import type { GalleryImage, ManagementListParams, SectionRecords, UniversityProgram, UniversitySection } from "@/lib/api-client/university-management";
import { normalizeApiError } from "@/lib/api-client/error";
import { ContentFormPage } from "@/components/content/content-form-page";
import { StatusBadge } from "@/components/content/status-badge";
import { ErrorState, EmptyState, LoadingState } from "@/components/dashboard/states";
import { useUniversitySection, useGalleryOrder } from "@/hook/queries/use-university-management";
import { useGalleryAction } from "@/hook/mutations/use-university-management";
import { useAdminAccess } from "@/providers/admin-access-provider";
import { admissionScopes, programStudyLevels, publicationStates, teachingLanguages } from "@/lib/university-schemas";
import { buttonClass, inputClass, PageControls, panelClass } from "./controls";
import { SectionEditor } from "./section-editor";

const labels: Record<UniversitySection | "overview", string> = { overview: "بيانات الجامعة", programs: "البرامج والرسوم", "admission-requirements": "متطلبات القبول", gallery: "معرض الصور" };

const billingLabels = { YEAR: "سنويًا", SEMESTER: "لكل فصل دراسي", FULL_PROGRAM: "لكامل البرنامج" };
function FeeValue({ fee }: { fee: NonNullable<UniversityProgram["tuition"]> }) {
  return <><bdi dir="ltr">{fee.amount} {fee.currency}</bdi> · {billingLabels[fee.billingPeriod]} · <bdi dir="ltr">{fee.academicYear}</bdi></>;
}
function ProgramFees({ program }: { program: UniversityProgram }) {
  return <section className="space-y-2 rounded-lg border border-[var(--line)] p-3 text-sm" aria-label="الرسوم الدراسية">
    <p><strong>الرسوم الحالية: </strong>{program.tuition ? <FeeValue fee={program.tuition} /> : "غير متاحة"}</p>
    {program.tuitionFees.length ? <details><summary className="min-h-11 cursor-pointer py-2 font-semibold">سجل الرسوم حسب السنة الأكاديمية ({program.tuitionFees.length})</summary>
      <ul className="space-y-1">{program.tuitionFees.map((fee, index) => <li key={`${fee?.id ?? "unavailable"}-${index}`}>{fee ? <FeeValue fee={fee} /> : "سجل رسوم غير متاح"}</li>)}</ul>
    </details> : <p className="text-[var(--muted)]">لا يوجد سجل رسوم.</p>}
  </section>;
}

function GalleryPreview({ image }: { image: GalleryImage }) {
  const [failed, setFailed] = useState(false);
  let usable = false;
  try { usable = ["http:", "https:"].includes(new URL(image.imageUrl).protocol); } catch { /* Unusable URL is a content state. */ }
  if (!usable || failed) return <p role="status" className="rounded-lg border border-dashed border-[var(--line)] p-3 text-sm">تعذّر عرض صورة المعرض. يمكنك مراجعة الرابط أو تعديل بيانات الصورة.</p>;
  return <img src={image.imageUrl} alt={image.altAr ?? "صورة الجامعة"} onError={() => setFailed(true)} className="max-h-48 max-w-full rounded-lg object-contain" />;
}
function OrderEditor({ images, universityId, close }: { images: GalleryImage[]; universityId: string; close: () => void }) {
  const [order, setOrder] = useState(images); const [stale, setStale] = useState(false); const [error, setError] = useState(""); const mutation = useGalleryAction(universityId);
  function move(index: number, delta: number) { setOrder(items => { const next = [...items]; [next[index], next[index + delta]] = [next[index + delta], next[index]]; return next; }); }
  return <div className={panelClass}><h3 className="font-bold">ترتيب جميع الصور غير المؤرشفة ({order.length})</h3><p className="text-sm">يشمل المسودات والمنشور. الترتيب مستقل عن مرشح القائمة.</p>{order.map((image, index) => <div key={image.id} className="flex flex-wrap items-center gap-2 border-b border-[var(--line)] py-2"><span className="min-w-0 flex-1 break-words">{index + 1}. {image.altAr ?? "صورة بلا وصف"}</span><button type="button" aria-label={`رفع الصورة ${index + 1}`} className={buttonClass} disabled={stale || mutation.isPending || index === 0} onClick={() => move(index, -1)}>أعلى</button><button type="button" aria-label={`خفض الصورة ${index + 1}`} className={buttonClass} disabled={stale || mutation.isPending || index === order.length - 1} onClick={() => move(index, 1)}>أسفل</button></div>)}{error ? <p role="alert" className="text-red-700">{error}</p> : null}<div className="flex flex-wrap gap-3"><button className={buttonClass} disabled={stale || mutation.isPending || !order.length} onClick={async () => { try { await mutation.mutateAsync({ orderedIds: order.map(image => image.id) }); close(); } catch (failure) { if (normalizeApiError(failure).status === 409) { setStale(true); setError("تغيّرت مجموعة الصور على الخادم. لم يُعاد الطلب. أغلق الترتيب وأعد تحميله صراحة قبل الحفظ."); } else setError("تعذّر حفظ الترتيب. لم تُفقد القائمة المحلية."); } }}>حفظ الترتيب</button><button className={buttonClass} disabled={mutation.isPending} onClick={close}>إغلاق الترتيب</button></div></div>;
}
function GalleryOrder({ universityId, close }: { universityId: string; close: () => void }) {
  const query = useGalleryOrder(universityId);
  return query.isPending || query.isFetching ? <LoadingState /> : query.isError ? <div className={panelClass}><p role="alert">{query.error instanceof Error && query.error.message.startsWith("عقد") ? query.error.message : "تعذّر تحميل المجموعة الكاملة. لا يمكن إرسال ترتيب جزئي."}</p><button className={buttonClass} onClick={() => void query.refetch()}>إعادة تحميل المجموعة</button><button className={buttonClass} onClick={close}>إلغاء الترتيب</button></div> : <OrderEditor images={query.data} universityId={universityId} close={close} />;
}
function SectionPanel<K extends UniversitySection>({ section, universityId }: { section: K; universityId: string }) {
  const [params, setParams] = useState<ManagementListParams>({ page: 1, limit: 12 }); const [editor, setEditor] = useState<SectionRecords[K] | "new">(); const [ordering, setOrdering] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const list = useUniversitySection(section, universityId, params); const action = useGalleryAction(universityId);
  const close = (saved = false) => { setEditor(undefined); setNotice(saved ? "تم حفظ السجل بنجاح." : ""); };
  return <section className="space-y-4"><div className="flex flex-wrap gap-3"><h2 className="flex-1 text-xl font-bold">{labels[section]}</h2><button className={buttonClass} disabled={Boolean(editor) || ordering} onClick={() => { setNotice(""); setEditor("new"); }}>إضافة سجل</button>{section === "gallery" ? <button className={buttonClass} disabled={Boolean(editor) || ordering} onClick={() => setOrdering(true)}>ترتيب الصور</button> : null}</div>{notice ? <p role="status">{notice}</p> : null}
    {editor ? <SectionEditor key={editor === "new" ? "new" : editor.id} section={section} universityId={universityId} record={editor === "new" ? undefined : editor} close={close} /> : null}
    {ordering ? <GalleryOrder universityId={universityId} close={() => setOrdering(false)} /> : null}
    <form className={`${panelClass} grid gap-3 sm:grid-cols-2 lg:grid-cols-3`} onSubmit={event => { event.preventDefault(); const data = new FormData(event.currentTarget); setParams(Object.fromEntries([...data.entries()].filter(([, value]) => value !== "").map(([key, value]) => [key, key === "limit" ? Number(value) : value])) as ManagementListParams); }}>
      {section === "programs" ? <><input aria-label="بحث البرامج" name="search" maxLength={200} className={inputClass} placeholder="بحث البرامج" /><input aria-label="الكلية" name="faculty" maxLength={200} className={inputClass} placeholder="الكلية" /><select aria-label="تصفية المستوى" name="studyLevel" className={inputClass}><option value="">كل المستويات</option>{programStudyLevels.map(value => <option key={value}>{value}</option>)}</select><select aria-label="تصفية اللغة" name="language" className={inputClass}><option value="">كل اللغات</option>{teachingLanguages.map(value => <option key={value}>{value}</option>)}</select></> : section === "admission-requirements" ? <select aria-label="تصفية النطاق" name="scope" className={inputClass}><option value="">كل النطاقات</option>{admissionScopes.map(value => <option key={value}>{value}</option>)}</select> : null}
      <select aria-label="تصفية الحالة" name="status" className={inputClass}><option value="">كل الحالات</option>{publicationStates.map(value => <option key={value}>{value}</option>)}</select><select aria-label="عدد السجلات" name="limit" defaultValue="12" className={inputClass}>{[12, 50, ...(section !== "programs" ? [100] : [])].map(value => <option key={value}>{value}</option>)}</select><button className={buttonClass}>تطبيق المرشحات</button>
    </form>
    {list.isPending ? <LoadingState /> : list.isError ? <ErrorState action={<button className={buttonClass} onClick={() => void list.refetch()}>إعادة المحاولة</button>} /> : list.data.items.length === 0 ? <EmptyState /> : <div className="grid gap-3">{list.data.items.map(item => <article className={panelClass} key={item.id}><div className="flex flex-wrap items-center justify-between gap-3"><h3 className="min-w-0 break-words font-bold">{"nameAr" in item ? item.nameAr ?? item.academicMajor.nameAr : "contentAr" in item ? item.contentAr : item.altAr ?? "صورة بلا وصف"}</h3><StatusBadge status={item.status} /></div>{"imageUrl" in item ? <GalleryPreview key={item.imageUrl} image={item} /> : null}{"scope" in item ? <p className="text-sm">{item.scope} · {item.program?.nameAr ?? (item.studyLevel ?? "الجامعة")}</p> : null}{"languages" in item ? <><p className="text-sm">{item.studyLevel} · {item.languages.join("، ")}</p><ProgramFees program={item} /></> : null}<div className="flex flex-wrap gap-3"><button className={buttonClass} disabled={Boolean(editor) || ordering} onClick={() => { setNotice(""); setEditor(item); }}>تعديل السجل</button>{section === "gallery" ? <button className={buttonClass} disabled={action.isPending || Boolean(editor) || ordering} onClick={async () => { if (!window.confirm("فصل الصورة عن معرض الجامعة فقط؟ لن يُحذف ملف Cloudinary أو غلاف الجامعة.")) return; try { await action.mutateAsync({ detach: item.id }); setNotice("تم فصل الصورة عن المعرض."); } catch { setError("تعذّر فصل الصورة. لم تتغير القائمة."); } }}>فصل من المعرض</button> : null}</div></article>)}</div>}{error ? <p role="alert">{error}</p> : null}<PageControls data={list.data} change={page => setParams(old => ({ ...old, page }))} />
  </section>;
}
export function UniversityWorkspace({ id }: { id: string }) {
  const [tab, setTab] = useState<UniversitySection | "overview">("overview"); const access = useAdminAccess();
  return <div className="space-y-5"><nav aria-label="إدارة الجامعة" className="flex flex-wrap gap-2">{Object.entries(labels).map(([key, label]) => <button key={key} className={buttonClass} aria-current={tab === key ? "page" : undefined} disabled={access.mockEnabled && key !== "overview"} onClick={() => setTab(key as typeof tab)}>{label}</button>)}</nav>{access.mockEnabled ? <p className="text-sm">إدارة Phase 2 تتطلب جلسة Backend؛ المعاينة القديمة محفوظة ولا تتصل بالبيانات الحقيقية.</p> : null}{tab === "overview" ? <ContentFormPage resource="universities" id={id} /> : <SectionPanel key={tab} section={tab} universityId={id} />}</div>;
}
